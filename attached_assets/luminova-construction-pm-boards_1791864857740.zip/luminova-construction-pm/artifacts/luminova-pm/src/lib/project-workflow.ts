export const PROJECT_TABS = ["board", "overview", "photos", "budget", "trades", "activity"] as const
export type ProjectTab = (typeof PROJECT_TABS)[number]

/** The board is the project's home for the internal team; clients, who can't open boards, land on the overview. */
export function projectTabFromSearch(search: string, canUseBoard = true): ProjectTab {
  const value = new URLSearchParams(search).get("tab")
  const tab = PROJECT_TABS.find(candidate => candidate === value) ?? (canUseBoard ? "board" : "overview")
  return tab === "board" && !canUseBoard ? "overview" : tab
}

export function projectWorkflowHref(path: string, projectId: string, extra: Record<string, string> = {}) {
  const query = new URLSearchParams({ projectId, ...extra })
  return `${path}?${query}`
}