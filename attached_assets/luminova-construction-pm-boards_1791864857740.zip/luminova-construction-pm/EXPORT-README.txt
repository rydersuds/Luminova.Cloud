Luminova Construction PM — source export

This archive contains the current working source, workspace packages, tests,
app assets, dependency lockfile, and project configuration.

Use Node.js 24 and pnpm. Install dependencies with pnpm install.
See package.json and each workspace package.json for build and run commands.

Secrets and environment variable values are intentionally NOT included.
Configure your own PostgreSQL database, Clerk authentication, storage, and
AI credentials/services as needed. Replit-managed integrations and the
preview routing environment are not transferred by this ZIP; outside Replit,
these require equivalent configuration.

This is a source export, not a database backup or a standalone offline app.
Live database records and private files in cloud storage are not included.
Dependencies, compiled output, screenshots, original reference uploads, Git
history, and agent/tool caches are excluded. App assets inside the source
packages are included.
