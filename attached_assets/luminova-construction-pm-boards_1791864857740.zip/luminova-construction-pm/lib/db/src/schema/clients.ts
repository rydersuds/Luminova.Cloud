import { index, pgTable, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const clientsTable = pgTable("clients", {
  id: text("id").primaryKey(),
  workspaceId: text("workspace_id").notNull(),
  name: text("name").notNull(),
  logoObjectPath: text("logo_object_path"),
  pendingLogoObjectPath: text("pending_logo_object_path"),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("clients_workspace_name_unique").on(table.workspaceId, table.name),
  index("clients_workspace_idx").on(table.workspaceId),
]);

export const clientMembersTable = pgTable("client_members", {
  id: text("id").primaryKey(),
  clientId: text("client_id").notNull(),
  userId: text("user_id").notNull(),
  addedBy: text("added_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  uniqueIndex("client_members_client_user_unique").on(table.clientId, table.userId),
  index("client_members_client_idx").on(table.clientId),
  index("client_members_user_idx").on(table.userId),
]);

export const clientAccessCleanupTable = pgTable("client_access_cleanup", {
  workspaceId: text("workspace_id").notNull(),
  userId: text("user_id").notNull(),
  failedAt: timestamp("failed_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("client_access_cleanup_workspace_user_unique").on(table.workspaceId, table.userId),
  index("client_access_cleanup_workspace_idx").on(table.workspaceId),
]);

export const clientInvitationsTable = pgTable("client_invitations", {
  id: text("id").primaryKey(),
  invitationId: text("invitation_id").notNull(),
  workspaceId: text("workspace_id").notNull(),
  clientId: text("client_id").notNull(),
  email: text("email").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  uniqueIndex("client_invitations_workspace_invitation_unique").on(table.workspaceId, table.invitationId),
  uniqueIndex("client_invitations_workspace_client_email_unique").on(table.workspaceId, table.clientId, table.email),
  index("client_invitations_workspace_idx").on(table.workspaceId),
  index("client_invitations_client_idx").on(table.clientId),
]);

export const insertClientSchema = createInsertSchema(clientsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export const insertClientMemberSchema = createInsertSchema(clientMembersTable).omit({
  createdAt: true,
});

export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clientsTable.$inferSelect;
export type InsertClientMember = z.infer<typeof insertClientMemberSchema>;
export type ClientMember = typeof clientMembersTable.$inferSelect;
export type ClientAccessCleanup = typeof clientAccessCleanupTable.$inferSelect;
export const insertClientInvitationSchema = createInsertSchema(clientInvitationsTable).omit({
  createdAt: true,
});
export type InsertClientInvitation = z.infer<typeof insertClientInvitationSchema>;
export type ClientInvitation = typeof clientInvitationsTable.$inferSelect;
